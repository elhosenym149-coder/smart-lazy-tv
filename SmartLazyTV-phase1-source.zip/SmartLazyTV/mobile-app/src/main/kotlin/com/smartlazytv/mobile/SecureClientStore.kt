package com.smartlazytv.mobile

import android.content.Context
import android.os.Build

/** Session token is stored encrypted with a Keystore key; host and device name are not secret. */
class SecureClientStore(context: Context) : TvClient.ClientStore {
    private val prefs = context.getSharedPreferences("client", Context.MODE_PRIVATE)

    override fun loadToken(): String? {
        val enc = prefs.getString("token_enc", null) ?: return null
        return try { KeystoreBox.decrypt(enc) } catch (e: Exception) { null }
    }

    override fun saveToken(token: String) {
        prefs.edit().putString("token_enc", KeystoreBox.encrypt(token)).apply()
    }

    override fun clearToken() {
        prefs.edit().remove("token_enc").apply()
    }

    override fun loadHost(): String? = prefs.getString("host", null)

    override fun saveHost(host: String) {
        prefs.edit().putString("host", host).apply()
    }

    override fun deviceName(): String = Build.MODEL.ifBlank { "Android" }
}

/** Keeps one TvClient per process so the connection survives Activity re-creation. */
object ClientHolder {
    @Volatile private var instance: TvClient? = null

    fun get(context: Context): TvClient =
        instance ?: synchronized(this) {
            instance ?: TvClient(SecureClientStore(context.applicationContext)).also { instance = it }
        }
}
