package com.smartlazytv.mobile

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.smartlazytv.core.Message
import com.smartlazytv.core.MessageType
import com.smartlazytv.core.Protocol
import com.smartlazytv.core.TvCommand
import com.smartlazytv.core.TvEvent
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONObject
import java.net.URI
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Phone-side connection to the TV (spec section 6).
 * Flow: open socket -> PAIR_REQUEST (first time, with the on-screen code) or AUTH (saved token) -> heartbeat every 2 s.
 * If the link drops it retries with the saved token (1 s, 2 s, 4 s, then every 8 s) until disconnect() is called.
 * All listener callbacks run on the main thread. Every public method is safe to call from any thread.
 */
class TvClient(private val store: ClientStore) {

    enum class State { DISCONNECTED, CONNECTING, CONNECTED, RECONNECTING }

    interface Listener {
        fun onState(state: State, detail: String)
        fun onLog(line: String)
        fun onRtt(ms: Long)
    }

    interface ClientStore {
        fun loadToken(): String?
        fun saveToken(token: String)
        fun clearToken()
        fun loadHost(): String?
        fun saveHost(host: String)
        fun deviceName(): String
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 8_000L
        private const val INITIAL_BACKOFF_MS = 1_000L
        private const val MAX_BACKOFF_MS = 8_000L
    }

    @Volatile var listener: Listener? = null

    @Volatile var currentState: State = State.DISCONNECTED
        private set
    @Volatile var currentDetail: String = ""
        private set
    @Volatile var lastRttMs: Long = -1
        private set

    private val main = Handler(Looper.getMainLooper())
    private val scheduler = Executors.newSingleThreadScheduledExecutor()
    private var socket: WebSocketClient? = null
    private var attempt = 0
    private var host = ""
    private var pairingCode: String? = null
    private var userWantsConnection = false
    private var sessionId: String? = null
    private var lastPongAt = 0L
    private var backoffMs = INITIAL_BACKOFF_MS
    private var reconnectPending = false
    private var heartbeatTask: ScheduledFuture<*>? = null
    private var watchdogTask: ScheduledFuture<*>? = null
    private var retryTask: ScheduledFuture<*>? = null
    private val pending = ConcurrentHashMap<String, Pair<String, Long>>()

    fun hasSavedPairing(): Boolean = store.loadToken() != null
    fun savedHost(): String? = store.loadHost()

    // ---------------- public API ----------------

    @Synchronized
    fun pairAndConnect(host: String, code: String) {
        this.host = host.trim()
        pairingCode = code
        userWantsConnection = true
        backoffMs = INITIAL_BACKOFF_MS
        openSocket(State.CONNECTING)
    }

    @Synchronized
    fun connectSaved(host: String) {
        if (store.loadToken() == null) {
            setState(State.DISCONNECTED, "لا يوجد اقتران محفوظ — اقترن أولًا")
            return
        }
        this.host = host.trim()
        pairingCode = null
        userWantsConnection = true
        backoffMs = INITIAL_BACKOFF_MS
        openSocket(State.CONNECTING)
    }

    @Synchronized
    fun disconnect(detail: String = "تم الفصل") {
        userWantsConnection = false
        stopTimers()
        closeSocket()
        sessionId = null
        setState(State.DISCONNECTED, detail)
    }

    /** Tells the TV to forget this phone (best effort), forgets the token locally, disconnects. */
    @Synchronized
    fun unpair() {
        if (currentState == State.CONNECTED) send(socket, MessageType.UNPAIR)
        store.clearToken()
        disconnect("أُلغي الاقتران")
    }

    @Synchronized
    fun sendCommand(
        command: TvCommand,
        params: Map<String, Double> = emptyMap(),
        confidence: Double = 1.0,
        source: String = "mobile:test-button",
        target: String? = null
    ): Boolean {
        val sid = sessionId
        val ws = socket
        if (currentState != State.CONNECTED || sid == null || ws == null) return false
        val event = TvEvent(UUID.randomUUID().toString(), command, source, System.currentTimeMillis(), confidence, target, params, sid)
        return try {
            ws.send(Message(MessageType.EVENT, event.toPayload()).encode())
            if (command != TvCommand.POINTER_MOVE) {
                if (pending.size > 200) pending.clear()
                pending[event.eventId] = command.name to SystemClock.elapsedRealtime()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------------- connection lifecycle ----------------

    private fun openSocket(initial: State) {
        stopTimers()
        closeSocket()
        val id = ++attempt
        val uri = try {
            URI("ws://$host:${Protocol.DEFAULT_PORT}")
        } catch (e: Exception) {
            fatal("عنوان التلفزيون غير صالح")
            return
        }
        setState(initial, "الاتصال بـ $host")
        val ws = object : WebSocketClient(uri) {
            override fun onOpen(handshakedata: ServerHandshake?) = onSocketOpen(id, this)
            override fun onMessage(message: String?) { if (message != null) onSocketMessage(id, message) }
            override fun onClose(code: Int, reason: String?, remote: Boolean) = onSocketClosed(id, reason ?: "")
            override fun onError(ex: Exception?) = onSocketError(id, ex)
        }
        ws.connectionLostTimeout = 6
        socket = ws
        ws.connect()
        watchdogTask = scheduler.schedule(Runnable { onWatchdog(id) }, CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)
    }

    @Synchronized
    private fun onSocketOpen(id: Int, ws: WebSocketClient) {
        if (id != attempt) return
        val code = pairingCode
        if (code != null) {
            send(ws, MessageType.PAIR_REQUEST, JSONObject().put("code", code).put("name", store.deviceName()))
        } else {
            val token = store.loadToken()
            if (token == null) {
                fatal("لا يوجد اقتران محفوظ — اقترن أولًا")
                return
            }
            send(ws, MessageType.AUTH, JSONObject().put("token", token).put("name", store.deviceName()))
        }
    }

    @Synchronized
    private fun onSocketMessage(id: Int, text: String) {
        if (id != attempt) return
        val msg = Message.decode(text) ?: return
        val p = msg.payload
        when (msg.type) {
            MessageType.PAIR_OK -> {
                store.saveToken(p.optString("token", ""))
                store.saveHost(host)
                pairingCode = null
                onAuthenticated(id, p.optString("sid", ""))
                log("تم الاقتران وحُفظ الرمز بشكل مشفّر")
            }
            MessageType.AUTH_OK -> onAuthenticated(id, p.optString("sid", ""))
            MessageType.PAIR_FAIL -> fatal(
                when (p.optString("reason")) {
                    "wrong_code" -> "رمز الاقتران غير صحيح"
                    "expired" -> "انتهت صلاحية الرمز — اقرأ الرمز الجديد من التلفزيون"
                    "locked" -> "محاولات خاطئة كثيرة — انتظر دقيقة"
                    else -> "رُفض الاقتران"
                }
            )
            MessageType.AUTH_FAIL -> {
                store.clearToken()
                fatal("الاقتران لم يعد صالحًا — اقترن من جديد")
            }
            MessageType.PONG -> {
                val now = SystemClock.elapsedRealtime()
                lastPongAt = now
                val rtt = now - p.optLong("t", now)
                lastRttMs = rtt
                main.post { listener?.onRtt(rtt) }
            }
            MessageType.ACK -> {
                val sent = pending.remove(p.optString("id"))
                if (sent != null) {
                    log("${sent.first}: ${p.optString("status")} خلال ${SystemClock.elapsedRealtime() - sent.second} مللي ثانية")
                } else if (p.optString("status") != "RECEIVED") {
                    log("ACK ${p.optString("status")}")
                }
            }
            else -> Unit
        }
    }

    private fun onAuthenticated(id: Int, sid: String) {
        sessionId = sid
        backoffMs = INITIAL_BACKOFF_MS
        watchdogTask?.cancel(false)
        lastPongAt = SystemClock.elapsedRealtime()
        setState(State.CONNECTED, "المضيف $host")
        heartbeatTask = scheduler.scheduleWithFixedDelay(
            Runnable { onHeartbeatTick(id) },
            Protocol.HEARTBEAT_INTERVAL_MS, Protocol.HEARTBEAT_INTERVAL_MS, TimeUnit.MILLISECONDS
        )
    }

    @Synchronized
    private fun onHeartbeatTick(id: Int) {
        try {
            if (id != attempt || currentState != State.CONNECTED) return
            val now = SystemClock.elapsedRealtime()
            if (now - lastPongAt > Protocol.HEARTBEAT_TIMEOUT_MS) {
                log("لا يوجد رد من التلفزيون")
                handleLost("انتهت مهلة النبض")
                return
            }
            send(socket, MessageType.PING, JSONObject().put("t", now).put("rtt", lastRttMs))
        } catch (e: Exception) {
            log("خطأ في النبض: ${e.message}") // a throwing scheduled task would silently stop forever
        }
    }

    @Synchronized
    private fun onWatchdog(id: Int) {
        if (id == attempt && userWantsConnection && currentState != State.CONNECTED) handleLost("انتهت مهلة الاتصال")
    }

    @Synchronized
    private fun onSocketClosed(id: Int, reason: String) {
        if (id != attempt || !userWantsConnection) return
        handleLost(if (reason.isBlank()) "انقطع الاتصال" else reason)
    }

    @Synchronized
    private fun onSocketError(id: Int, ex: Exception?) {
        if (id != attempt) return
        log("خطأ شبكة: ${ex?.message ?: ex?.javaClass?.simpleName}")
    }

    private fun handleLost(reason: String) {
        if (!userWantsConnection) return
        if (pairingCode != null) { // first-time pairing: do not loop on a one-time code
            fatal("تعذّر إكمال الاقتران: $reason")
            return
        }
        stopTimers()
        closeSocket()
        sessionId = null
        scheduleReconnect(reason)
    }

    private fun scheduleReconnect(reason: String) {
        if (!userWantsConnection || reconnectPending) return
        reconnectPending = true
        val delay = backoffMs
        backoffMs = minOf(backoffMs * 2, MAX_BACKOFF_MS)
        setState(State.RECONNECTING, "$reason — إعادة المحاولة بعد ${delay / 1000} ث")
        retryTask = scheduler.schedule(Runnable { retryNow() }, delay, TimeUnit.MILLISECONDS)
    }

    @Synchronized
    private fun retryNow() {
        reconnectPending = false
        if (userWantsConnection && pairingCode == null) openSocket(State.RECONNECTING)
    }

    /** Unrecoverable for this attempt (wrong code, revoked pairing, bad address): stop retrying. */
    private fun fatal(message: String) {
        userWantsConnection = false
        stopTimers()
        closeSocket()
        sessionId = null
        setState(State.DISCONNECTED, message)
    }

    private fun stopTimers() {
        heartbeatTask?.cancel(false); heartbeatTask = null
        watchdogTask?.cancel(false); watchdogTask = null
        retryTask?.cancel(false); retryTask = null
        reconnectPending = false
    }

    private fun closeSocket() {
        attempt++ // invalidates callbacks from the old socket
        val s = socket
        socket = null
        try { s?.close() } catch (e: Exception) { /* already closed */ }
    }

    // ---------------- helpers ----------------

    private fun send(ws: WebSocketClient?, type: MessageType, payload: JSONObject = JSONObject()) {
        try { ws?.send(Message(type, payload).encode()) } catch (e: Exception) { /* closed; onClose will handle it */ }
    }

    private fun setState(s: State, detail: String) {
        currentState = s
        currentDetail = detail
        main.post { listener?.onState(s, detail) }
    }

    private fun log(line: String) {
        main.post { listener?.onLog(line) }
    }
}
