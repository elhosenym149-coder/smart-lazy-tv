package com.smartlazytv.mobile

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.smartlazytv.core.Protocol
import com.smartlazytv.core.TvCommand
import com.smartlazytv.core.normalizeDigits
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase 1 screen: pair with the TV, show connection state and latency, send test commands, show the log.
 * Motion sensing (Air Mouse / gestures) starts in phase 2.
 */
class MainActivity : Activity(), TvClient.Listener {

    private lateinit var client: TvClient
    private lateinit var statusView: TextView
    private lateinit var rttView: TextView
    private lateinit var hostInput: EditText
    private lateinit var codeInput: EditText
    private lateinit var logView: TextView
    private lateinit var commandContainer: LinearLayout
    private val commandButtons = ArrayList<Button>()
    private val logLines = ArrayList<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val hostRegex = Regex("""^\d{1,3}(\.\d{1,3}){3}$""")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        client = ClientHolder.get(applicationContext)

        statusView = findViewById(R.id.statusView)
        rttView = findViewById(R.id.rttView)
        hostInput = findViewById(R.id.hostInput)
        codeInput = findViewById(R.id.codeInput)
        logView = findViewById(R.id.logView)
        commandContainer = findViewById(R.id.commandContainer)

        hostInput.setText(client.savedHost() ?: "")
        findViewById<Button>(R.id.btnPair).setOnClickListener { onPairClicked() }
        findViewById<Button>(R.id.btnConnect).setOnClickListener { onConnectSavedClicked() }
        findViewById<Button>(R.id.btnDisconnect).setOnClickListener { client.disconnect() }
        findViewById<Button>(R.id.btnUnpair).setOnClickListener { client.unpair() }
        buildCommandButtons()

        // Auto-reconnect to a previously paired TV when the app is opened fresh.
        if (savedInstanceState == null && client.currentState == TvClient.State.DISCONNECTED && client.hasSavedPairing()) {
            val saved = client.savedHost()
            if (!saved.isNullOrBlank()) client.connectSaved(saved)
        }
    }

    override fun onStart() {
        super.onStart()
        client.listener = this
        render(client.currentState, client.currentDetail)
    }

    override fun onStop() {
        if (client.listener === this) client.listener = null
        super.onStop()
    }

    override fun onState(state: TvClient.State, detail: String) {
        render(state, detail)
        addLog("${stateLabel(state)}${if (detail.isBlank()) "" else " — $detail"}")
    }

    override fun onLog(line: String) = addLog(line)

    override fun onRtt(ms: Long) {
        rttView.text = getString(R.string.rtt_fmt, ms)
    }

    private fun onPairClicked() {
        val host = hostInput.text.toString().trim()
        val code = normalizeDigits(codeInput.text.toString())
        if (!hostRegex.matches(host)) return toast(R.string.err_host)
        if (code.length != Protocol.PAIRING_CODE_LENGTH) return toast(R.string.err_code)
        client.pairAndConnect(host, code)
    }

    private fun onConnectSavedClicked() {
        if (!client.hasSavedPairing()) return toast(R.string.err_not_paired)
        val host = hostInput.text.toString().trim().ifBlank { client.savedHost() ?: "" }
        if (!hostRegex.matches(host)) return toast(R.string.err_host)
        client.connectSaved(host)
    }

    private fun buildCommandButtons() {
        val commands = TvCommand.values().filter { it != TvCommand.POINTER_MOVE } // pointer streaming comes with phase 2
        for (chunk in commands.chunked(3)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (cmd in chunk) {
                val b = Button(this)
                b.text = cmd.name
                b.textSize = 11f
                b.setAllCaps(false)
                b.isEnabled = false
                b.setOnClickListener {
                    val ok = client.sendCommand(cmd)
                    addLog(if (ok) "أُرسل ${cmd.name}" else "تعذّر الإرسال (غير متصل)")
                }
                row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                commandButtons.add(b)
            }
            commandContainer.addView(row)
        }
    }

    private fun render(state: TvClient.State, detail: String) {
        val label = stateLabel(state)
        statusView.text = if (detail.isBlank()) label else "$label — $detail"
        statusView.setTextColor(
            when (state) {
                TvClient.State.CONNECTED -> 0xFF66BB6A.toInt()
                TvClient.State.DISCONNECTED -> 0xFFEF5350.toInt()
                else -> 0xFFFFA726.toInt()
            }
        )
        if (state != TvClient.State.CONNECTED) rttView.text = ""
        val connected = state == TvClient.State.CONNECTED
        commandButtons.forEach { it.isEnabled = connected }
    }

    private fun stateLabel(state: TvClient.State): String = getString(
        when (state) {
            TvClient.State.DISCONNECTED -> R.string.state_disconnected
            TvClient.State.CONNECTING -> R.string.state_connecting
            TvClient.State.CONNECTED -> R.string.state_connected
            TvClient.State.RECONNECTING -> R.string.state_reconnecting
        }
    )

    private fun addLog(line: String) {
        logLines.add(0, "${timeFormat.format(Date())}  $line")
        while (logLines.size > 15) logLines.removeAt(logLines.size - 1)
        logView.text = logLines.joinToString("\n")
    }

    private fun toast(resId: Int) = Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
}
