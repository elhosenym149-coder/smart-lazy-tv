# _previous

Earlier attempt at shared-core (kotlinx.serialization Envelope + PairingManager with plaintext token storage),
found in the project folder and moved here byte-for-byte (checksums verified) when the current
shared-core implementation was adopted. This folder is not a Gradle module and is not compiled.
Ideas worth porting later: `attemptsLeft` in the wrong-code result, injectable java.util.Random for seeded tests.
