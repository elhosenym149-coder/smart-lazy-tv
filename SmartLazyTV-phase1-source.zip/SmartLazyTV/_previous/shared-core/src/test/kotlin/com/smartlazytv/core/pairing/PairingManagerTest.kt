package com.smartlazytv.core.pairing

import java.util.Random
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

private class FakeStore : PairingStore {
    var token: String? = null
    override fun loadToken(): String? = token
    override fun saveToken(token: String) { this.token = token }
    override fun clearToken() { token = null }
}

class PairingManagerTest {
    private var now = 1_000_000L
    private val store = FakeStore()
    private fun manager() = PairingManager(store, clock = { now }, random = Random(1234))
    private fun wrongCodeFor(m: PairingManager) = if (m.currentCode() == "000000") "000001" else "000000"

    @Test
    fun correctCodeCreatesSessionToken() {
        val m = manager()
        val ok = assertIs<PairResult.Success>(m.tryPair(m.currentCode()))
        assertEquals(64, ok.sessionToken.length)
        assertTrue(m.isSessionValid(ok.sessionToken))
        assertEquals(ok.sessionToken, store.token)
        assertTrue(m.isPaired())
    }

    @Test
    fun wrongCodesCountDownThenLock() {
        val m = manager()
        val wrong = wrongCodeFor(m)
        for (left in 4 downTo 1) assertEquals(PairResult.WrongCode(left), m.tryPair(wrong))
        assertEquals(PairResult.Locked, m.tryPair(wrong))
        assertFalse(m.isPaired())
    }

    @Test
    fun lockBlocksEvenTheCorrectCodeUntilLockoutEnds() {
        val m = manager()
        val wrong = wrongCodeFor(m)
        repeat(5) { m.tryPair(wrong) }
        assertEquals(PairResult.Locked, m.tryPair(m.currentCode()))
        now += 31_000L
        assertIs<PairResult.Success>(m.tryPair(m.currentCode()))
    }

    @Test
    fun expiredCodeIsRejected() {
        val m = manager()
        val c = m.currentCode()
        now += 121_000L
        assertEquals(PairResult.Expired, m.tryPair(c))
    }

    @Test
    fun unpairInvalidatesToken() {
        val m = manager()
        val ok = assertIs<PairResult.Success>(m.tryPair(m.currentCode()))
        m.unpair()
        assertFalse(m.isSessionValid(ok.sessionToken))
        assertNull(store.token)
        assertFalse(m.isPaired())
    }

    @Test
    fun nullEmptyAndUnknownTokensAreInvalid() {
        val m = manager()
        assertFalse(m.isSessionValid(null))
        assertFalse(m.isSessionValid(""))
        assertFalse(m.isSessionValid("abc"))
    }

    @Test
    fun tokenFromPreviousRunSurvivesRestart() {
        store.token = "abc"
        val m = manager()
        assertTrue(m.isSessionValid("abc"))
    }
}
