package com.smartlazytv.core.protocol

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class EnvelopeCodecTest {
    @Test
    fun roundTripKeepsAllFields() {
        val e = Envelope(
            eventId = "e1", type = MessageType.COMMAND, source = "mobile", timestamp = 123L,
            confidence = 0.9f, command = Command.SELECT, sessionId = "s",
            params = mapOf("k" to "v"),
        )
        assertEquals(e, EnvelopeCodec.decode(EnvelopeCodec.encode(e)))
    }

    @Test
    fun garbageAndIncompleteJsonReturnNull() {
        assertNull(EnvelopeCodec.decode("not json"))
        assertNull(EnvelopeCodec.decode("{}"))
    }

    @Test
    fun unknownFieldsAreIgnored() {
        val text = """{"eventId":"a","type":"HEARTBEAT","source":"mobile","timestamp":1,"future":"x"}"""
        assertEquals(MessageType.HEARTBEAT, EnvelopeCodec.decode(text)?.type)
    }

    @Test
    fun unknownTypeReturnsNull() {
        val text = """{"eventId":"a","type":"NOPE","source":"mobile","timestamp":1}"""
        assertNull(EnvelopeCodec.decode(text))
    }

    @Test
    fun oversizedMessageIsRejected() {
        assertNull(EnvelopeCodec.decode("x".repeat(10_000)))
    }
}
