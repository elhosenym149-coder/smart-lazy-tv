package com.smartlazytv.core.protocol

import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

const val PROTOCOL_VERSION = 1
const val DEFAULT_PORT = 8765
private const val MAX_MESSAGE_CHARS = 8192

/** Transport-level message kinds. Everything the phone asks the TV to do travels as COMMAND. */
@Serializable
enum class MessageType {
    PAIR_REQUEST, PAIR_OK, PAIR_REJECT,
    HEARTBEAT, HEARTBEAT_ACK,
    COMMAND, COMMAND_ACK,
    UNPAIR, ERROR
}

/**
 * Unified command set (spec section 9). In Phase 1 these are only transported and acknowledged;
 * nothing is executed on the TV until the Action Gateway exists (Phase 4).
 */
@Serializable
enum class Command {
    POINTER_MOVE, SELECT,
    NAVIGATE_UP, NAVIGATE_DOWN, NAVIGATE_LEFT, NAVIGATE_RIGHT,
    BACK, HOME, VOLUME_UP, VOLUME_DOWN, MUTE, PLAY_PAUSE, MENU, LONG_SELECT, DISMISS
}

/** One wire message. Carries the fields required by spec section 9 (id, source, time, confidence, target, params, session). */
@Serializable
data class Envelope(
    val v: Int = PROTOCOL_VERSION,
    val eventId: String,
    val type: MessageType,
    val source: String,
    val timestamp: Long,
    val confidence: Float = 1.0f,
    val target: String? = null,
    val command: Command? = null,
    val params: Map<String, String> = emptyMap(),
    val sessionId: String? = null,
)

fun newEventId(): String = UUID.randomUUID().toString()

object EnvelopeCodec {
    private val json = Json { ignoreUnknownKeys = true }

    fun encode(envelope: Envelope): String = json.encodeToString(Envelope.serializer(), envelope)

    /** Returns null for anything malformed, oversized, or with an unknown message type. Never throws. */
    fun decode(text: String): Envelope? {
        if (text.length > MAX_MESSAGE_CHARS) return null
        return try {
            json.decodeFromString(Envelope.serializer(), text)
        } catch (e: Exception) {
            null
        }
    }
}
