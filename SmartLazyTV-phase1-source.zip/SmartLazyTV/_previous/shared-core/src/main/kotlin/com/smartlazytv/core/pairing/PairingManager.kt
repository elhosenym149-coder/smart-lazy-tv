package com.smartlazytv.core.pairing

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Random

/** Where the session token lives. Android implementations use EncryptedSharedPreferences when available. */
interface PairingStore {
    fun loadToken(): String?
    fun saveToken(token: String)
    fun clearToken()
}

sealed interface PairResult {
    data class Success(val sessionToken: String) : PairResult
    data class WrongCode(val attemptsLeft: Int) : PairResult
    object Expired : PairResult
    object Locked : PairResult
}

/**
 * TV-side pairing logic (spec section 6): temporary 6-digit code -> random session token.
 * - code expires after [codeTtlMs] and is single-use (rotated after every success);
 * - [maxAttempts] wrong guesses lock pairing for [lockoutMs] and rotate the code (brute-force limit);
 * - only one paired phone at a time in v1 (a new pairing replaces the old token).
 * [random] is a java.util.Random so tests can seed it; the default is SecureRandom.
 */
class PairingManager(
    private val store: PairingStore,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val random: Random = SecureRandom(),
    private val codeTtlMs: Long = 120_000L,
    private val maxAttempts: Int = 5,
    private val lockoutMs: Long = 30_000L,
) {
    private val lock = Any()
    private var code = ""
    private var codeIssuedAt = 0L
    private var failedAttempts = 0
    private var lockedUntil = 0L
    private var cachedToken: String? = store.loadToken()

    init {
        rotateCode()
    }

    /** The code to display. Rotates automatically once expired. */
    fun currentCode(): String = synchronized(lock) {
        if (clock() - codeIssuedAt > codeTtlMs) rotateCode()
        code
    }

    fun rotateCode(): String = synchronized(lock) {
        code = random.nextInt(1_000_000).toString().padStart(6, '0')
        codeIssuedAt = clock()
        failedAttempts = 0
        code
    }

    fun tryPair(candidate: String): PairResult = synchronized(lock) {
        val now = clock()
        if (now < lockedUntil) return PairResult.Locked
        if (now - codeIssuedAt > codeTtlMs) {
            rotateCode()
            return PairResult.Expired
        }
        if (!constantTimeEquals(candidate, code)) {
            failedAttempts++
            if (failedAttempts >= maxAttempts) {
                lockedUntil = now + lockoutMs
                rotateCode()
                return PairResult.Locked
            }
            return PairResult.WrongCode(maxAttempts - failedAttempts)
        }
        val token = newToken()
        store.saveToken(token)
        cachedToken = token
        rotateCode() // single-use code
        PairResult.Success(token)
    }

    /** True only for the token issued by the last successful pairing. Constant-time comparison. */
    fun isSessionValid(token: String?): Boolean {
        if (token.isNullOrEmpty()) return false
        val stored = synchronized(lock) { cachedToken } ?: return false
        return constantTimeEquals(token, stored)
    }

    fun isPaired(): Boolean = synchronized(lock) { cachedToken != null }

    fun unpair() {
        synchronized(lock) {
            store.clearToken()
            cachedToken = null
        }
    }

    private fun newToken(): String {
        val bytes = ByteArray(32)
        random.nextBytes(bytes)
        val hex = "0123456789abcdef"
        val sb = StringBuilder(64)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(hex[v ushr 4]).append(hex[v and 0x0F])
        }
        return sb.toString()
    }

    private fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
}
