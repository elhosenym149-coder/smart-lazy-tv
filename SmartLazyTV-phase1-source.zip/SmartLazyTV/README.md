# Smart Lazy TV

عصا تحكم حركية لاسلكية: الموبايل يتحكم بتلفزيون Android TV (Toshiba — Android TV 11).

## الحالة الحالية (صادقة)

| المرحلة | الحالة |
|---|---|
| 0 — فحص البيئة | تمّ جزئيًا. بيئة المساعد لا تحتوي Android SDK/Gradle ولا إنترنت، فلا يمكن بناء APK هناك. الحساسات لم تُفحص على جهاز فعلي. |
| 1 — التطبيقان والاتصال والاقتران | **الكود مكتوب، لم يُترجم ولم يُختبر.** لا توجد ملفات APK. |
| 2 — Air Mouse | لم تبدأ. تحتاج هاتفًا فيه جيروسكوب (Galaxy A03s ليس فيه). |
| 3–6 | لم تبدأ. |

لا تُعتبر المرحلة 1 مكتملة قبل نجاح البناء والاختبارات الموثقة في `documentation/Testing.md`.

## البنية
- `shared-core/` — البروتوكول، الأوامر الموحدة، منطق الاقتران (Kotlin بدون اعتماد على واجهات Android، مع اختبارات وحدة).
- `mobile-app/` — تطبيق الهاتف (`com.smartlazytv.mobile`).
- `tv-app/` — تطبيق التلفزيون (`com.smartlazytv.tv`).
- `_previous/` — محاولة سابقة وُجدت في المجلد، نُقلت كما هي ولا تُترجم.
- `documentation/` — Architecture / Permissions / Testing / Known-Limitations / Installation-Guide-Arabic / CHANGELOG.

## البناء
اقرأ `documentation/Installation-Guide-Arabic.md`.
