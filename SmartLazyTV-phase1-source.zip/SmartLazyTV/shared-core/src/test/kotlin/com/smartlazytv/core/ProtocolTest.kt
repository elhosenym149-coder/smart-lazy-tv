package com.smartlazytv.core

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ProtocolTest {
    @Test
    fun messageRoundTrip() {
        val decoded = Message.decode(Message(MessageType.PING, JSONObject().put("t", 5)).encode())
        assertNotNull(decoded)
        assertEquals(MessageType.PING, decoded!!.type)
        assertEquals(5, decoded.payload.getInt("t"))
    }

    @Test
    fun rejectsGarbageWrongVersionUnknownTypeAndOversize() {
        assertNull(Message.decode("not json"))
        assertNull(Message.decode("""{"v":99,"t":"PING","p":{}}"""))
        assertNull(Message.decode("""{"v":1,"t":"NOPE","p":{}}"""))
        assertNull(Message.decode("x".repeat(Protocol.MAX_MESSAGE_CHARS + 1)))
    }

    @Test
    fun eventRoundTripKeepsEveryField() {
        val e = TvEvent("id1", TvCommand.SELECT, "test", 123L, 0.9, "btn", mapOf("x" to 0.5), "sid")
        assertEquals(e, tvEventFromPayload(e.toPayload()))
        val noTarget = e.copy(target = null, parameters = emptyMap())
        assertEquals(noTarget, tvEventFromPayload(noTarget.toPayload()))
    }

    @Test
    fun eventWithUnknownCommandIsRejected() {
        val p = TvEvent("i", TvCommand.BACK, "s", 1L, 1.0, null, emptyMap(), "sid").toPayload().put("cmd", "FORMAT_TV")
        assertNull(tvEventFromPayload(p))
    }

    @Test
    fun normalizeDigitsHandlesArabicIndicPersianAndNoise() {
        assertEquals("012345", normalizeDigits("٠١٢٣٤٥"))
        assertEquals("123", normalizeDigits("۱۲۳"))
        assertEquals("123456", normalizeDigits("123 456"))
    }
}
