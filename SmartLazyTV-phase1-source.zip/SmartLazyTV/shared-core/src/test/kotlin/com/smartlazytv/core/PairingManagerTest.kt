package com.smartlazytv.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeStore : PairingStore {
    var hash: String? = null
    var name: String? = null
    override fun loadTokenHash() = hash
    override fun loadPairedDeviceName() = name
    override fun save(tokenHash: String, deviceName: String) { hash = tokenHash; name = deviceName }
    override fun clear() { hash = null; name = null }
}

class PairingManagerTest {
    private var now = 0L
    private val store = FakeStore()
    private fun manager() = PairingManager(store, clock = { now })

    @Test
    fun successStoresHashNotToken() {
        val m = manager()
        val r = m.tryPair(m.currentCode(), "Phone")
        assertTrue(r is PairResult.Success)
        val token = (r as PairResult.Success).token
        assertNotEquals(token, store.hash)
        assertTrue(m.verifyToken(token))
        assertFalse(m.verifyToken("wrong"))
        assertEquals("Phone", m.pairedDeviceName())
    }

    @Test
    fun locksOutAfterFiveWrongCodesThenRecovers() {
        val m = manager()
        val bad = if (m.currentCode() == "000000") "111111" else "000000"
        repeat(4) { assertEquals(PairResult.WrongCode, m.tryPair(bad, "p")) }
        assertEquals(PairResult.LockedOut, m.tryPair(bad, "p"))
        assertEquals(PairResult.LockedOut, m.tryPair(m.currentCode(), "p")) // even the right code
        now += PairingManager.LOCKOUT_MS + 1_000
        assertTrue(m.tryPair(m.currentCode(), "p") is PairResult.Success)
    }

    @Test
    fun codeExpiresAndRotates() {
        val m = manager()
        now += PairingManager.CODE_TTL_MS + 1
        assertEquals(PairResult.Expired, m.tryPair(m.currentCode(), "p"))
        assertTrue(m.rotateIfExpired())
        assertTrue(m.tryPair(m.currentCode(), "p") is PairResult.Success)
    }

    @Test
    fun unpairInvalidatesToken() {
        val m = manager()
        val token = (m.tryPair(m.currentCode(), "p") as PairResult.Success).token
        m.unpair()
        assertFalse(m.verifyToken(token))
        assertFalse(m.isPaired())
    }
}
