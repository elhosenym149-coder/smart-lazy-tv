package com.smartlazytv.core

import org.json.JSONObject

/** Constants shared by the phone and the TV. Both sides MUST agree on these. */
object Protocol {
    const val VERSION = 1
    const val DEFAULT_PORT = 8765
    const val PAIRING_CODE_LENGTH = 6
    const val HEARTBEAT_INTERVAL_MS = 2_000L
    const val HEARTBEAT_TIMEOUT_MS = 6_000L
    const val AUTH_TIMEOUT_MS = 5_000L
    const val MAX_MESSAGE_CHARS = 4_096
}

enum class MessageType {
    PAIR_REQUEST, PAIR_OK, PAIR_FAIL,
    AUTH, AUTH_OK, AUTH_FAIL,
    PING, PONG,
    EVENT, ACK,
    UNPAIR
}

/** Unified command set (spec section 9). All TV actions go through these. */
enum class TvCommand {
    POINTER_MOVE, SELECT,
    NAVIGATE_UP, NAVIGATE_DOWN, NAVIGATE_LEFT, NAVIGATE_RIGHT,
    BACK, HOME, VOLUME_UP, VOLUME_DOWN, MUTE, PLAY_PAUSE, MENU,
    LONG_SELECT, DISMISS
}

/**
 * RECEIVED = the TV got the event. It does NOT mean the action was executed.
 * EXECUTED / FAILED will be added when the Action Gateway exists (phase 4).
 */
enum class AckStatus { RECEIVED, DUPLICATE, REJECTED }

/** Wire envelope: {"v":1,"t":"TYPE","p":{...}} */
data class Message(val type: MessageType, val payload: JSONObject = JSONObject()) {
    fun encode(): String =
        JSONObject().put("v", Protocol.VERSION).put("t", type.name).put("p", payload).toString()

    companion object {
        /** Returns null for anything malformed, oversized, or of another protocol version. */
        fun decode(text: String): Message? {
            if (text.length > Protocol.MAX_MESSAGE_CHARS) return null
            return try {
                val o = JSONObject(text)
                if (o.optInt("v", -1) != Protocol.VERSION) null
                else Message(MessageType.valueOf(o.getString("t")), o.optJSONObject("p") ?: JSONObject())
            } catch (e: Exception) {
                null
            }
        }
    }
}

/** Every command carries: id, source, timestamp, confidence, target, parameters, session (spec section 9). */
data class TvEvent(
    val eventId: String,
    val command: TvCommand,
    val source: String,
    val timestampMs: Long,
    val confidence: Double,
    val target: String?,
    val parameters: Map<String, Double>,
    val sessionId: String
) {
    fun toPayload(): JSONObject = JSONObject()
        .put("id", eventId)
        .put("cmd", command.name)
        .put("src", source)
        .put("ts", timestampMs)
        .put("conf", confidence)
        .put("target", target ?: JSONObject.NULL)
        .put("params", JSONObject(parameters))
        .put("sid", sessionId)
}

fun tvEventFromPayload(p: JSONObject): TvEvent? = try {
    val params = mutableMapOf<String, Double>()
    p.optJSONObject("params")?.let { o -> o.keys().forEach { k -> params[k] = o.getDouble(k) } }
    TvEvent(
        eventId = p.getString("id"),
        command = TvCommand.valueOf(p.getString("cmd")),
        source = p.getString("src"),
        timestampMs = p.getLong("ts"),
        confidence = p.getDouble("conf"),
        target = if (p.isNull("target")) null else p.getString("target"),
        parameters = params,
        sessionId = p.getString("sid")
    )
} catch (e: Exception) {
    null
}

/** Arabic-Indic and Persian digits -> ASCII, everything else that is not 0-9 is dropped. */
fun normalizeDigits(s: String): String {
    val sb = StringBuilder()
    for (c in s) {
        val mapped = when (c) {
            in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
            in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
            else -> c
        }
        if (mapped in '0'..'9') sb.append(mapped)
    }
    return sb.toString()
}
