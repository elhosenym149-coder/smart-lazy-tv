package com.smartlazytv.core

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

/** The TV stores only a SHA-256 hash of the session token, never the token itself. */
interface PairingStore {
    fun loadTokenHash(): String?
    fun loadPairedDeviceName(): String?
    fun save(tokenHash: String, deviceName: String)
    fun clear()
}

sealed class PairResult {
    data class Success(val token: String) : PairResult()
    object WrongCode : PairResult()
    object Expired : PairResult()
    object LockedOut : PairResult()
}

/**
 * TV-side pairing logic (spec section 6). Pure Kotlin, no Android dependency, so it is unit-testable.
 * - 6-digit code, valid 120 s, 5 wrong attempts -> 60 s lockout and a new code.
 * - A successful pairing consumes the code and returns a random 256-bit session token.
 */
class PairingManager(
    private val store: PairingStore,
    private val clock: () -> Long = System::currentTimeMillis,
    private val random: SecureRandom = SecureRandom()
) {
    companion object {
        const val CODE_TTL_MS = 120_000L
        const val MAX_FAILED_ATTEMPTS = 5
        const val LOCKOUT_MS = 60_000L
    }

    private var code = ""
    private var codeIssuedAt = 0L
    private var failedAttempts = 0
    private var lockedUntil = 0L

    init {
        issueCode()
    }

    private fun issueCode() {
        code = String.format(Locale.US, "%06d", random.nextInt(1_000_000))
        codeIssuedAt = clock()
        failedAttempts = 0
    }

    /** User-initiated: new code and clears any lockout. */
    @Synchronized
    fun regenerateCode(): String {
        issueCode()
        lockedUntil = 0
        return code
    }

    /** Automatic rotation: new code but keeps an active lockout. */
    @Synchronized
    fun rotateIfExpired(): Boolean {
        if (clock() - codeIssuedAt <= CODE_TTL_MS) return false
        issueCode()
        return true
    }

    @Synchronized fun currentCode(): String = code
    @Synchronized fun codeRemainingMs(): Long = maxOf(0L, CODE_TTL_MS - (clock() - codeIssuedAt))
    @Synchronized fun isPaired(): Boolean = store.loadTokenHash() != null
    @Synchronized fun pairedDeviceName(): String? = store.loadPairedDeviceName()

    @Synchronized
    fun tryPair(candidate: String, deviceName: String): PairResult {
        val now = clock()
        if (now < lockedUntil) return PairResult.LockedOut
        if (now - codeIssuedAt > CODE_TTL_MS) return PairResult.Expired
        if (!constantTimeEquals(candidate, code)) {
            failedAttempts++
            if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
                issueCode()
                lockedUntil = now + LOCKOUT_MS
                return PairResult.LockedOut
            }
            return PairResult.WrongCode
        }
        val token = newToken()
        store.save(sha256Hex(token), deviceName)
        issueCode() // single use
        return PairResult.Success(token)
    }

    @Synchronized
    fun verifyToken(token: String): Boolean {
        val stored = store.loadTokenHash() ?: return false
        return constantTimeEquals(sha256Hex(token), stored)
    }

    @Synchronized
    fun unpair() {
        store.clear()
        regenerateCode()
    }

    private fun newToken(): String {
        val b = ByteArray(32)
        random.nextBytes(b)
        return b.toHex()
    }

    private fun sha256Hex(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).toHex()

    private fun ByteArray.toHex(): String = joinToString("") { String.format(Locale.ROOT, "%02x", it) }

    private fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
}
