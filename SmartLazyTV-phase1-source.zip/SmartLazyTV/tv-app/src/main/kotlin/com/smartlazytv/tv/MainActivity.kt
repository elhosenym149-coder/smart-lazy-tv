package com.smartlazytv.tv

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import com.smartlazytv.core.TvEvent
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase 1 screen: connection status, address, pairing code, last received command, log.
 * Fully operable with a standard TV remote (every button is focusable; focus is highlighted).
 */
class MainActivity : Activity(), ReceiverRuntime.Listener {

    private lateinit var statusView: TextView
    private lateinit var addressView: TextView
    private lateinit var codeView: TextView
    private lateinit var expiryView: TextView
    private lateinit var pairedView: TextView
    private lateinit var lastCommandView: TextView
    private lateinit var logView: TextView
    private lateinit var toggleButton: Button

    private val main = Handler(Looper.getMainLooper())
    private val logLines = ArrayList<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            main.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        statusView = findViewById(R.id.statusView)
        addressView = findViewById(R.id.addressView)
        codeView = findViewById(R.id.codeView)
        expiryView = findViewById(R.id.expiryView)
        pairedView = findViewById(R.id.pairedView)
        lastCommandView = findViewById(R.id.lastCommandView)
        logView = findViewById(R.id.logView)
        toggleButton = findViewById(R.id.btnToggle)

        ReceiverRuntime.init(applicationContext)
        ReceiverRuntime.start()

        findViewById<Button>(R.id.btnNewCode).setOnClickListener {
            ReceiverRuntime.pairing.regenerateCode()
            refresh()
        }
        findViewById<Button>(R.id.btnUnpair).setOnClickListener {
            ReceiverRuntime.unpair()
            addLog("تم إلغاء الاقتران")
            refresh()
        }
        toggleButton.setOnClickListener {
            if (ReceiverRuntime.running) ReceiverRuntime.stop() else ReceiverRuntime.start()
            refresh()
        }
        findViewById<Button>(R.id.btnNewCode).requestFocus()
    }

    override fun onStart() {
        super.onStart()
        ReceiverRuntime.listener = this
        main.post(ticker)
    }

    override fun onStop() {
        ReceiverRuntime.listener = null
        main.removeCallbacks(ticker)
        super.onStop()
    }

    override fun onChanged() = refresh()

    override fun onLog(line: String) = addLog(line)

    override fun onCommand(event: TvEvent) {
        lastCommandView.text = "${event.command.name}  •  ${event.source}"
        addLog("استُقبل ${event.command.name} (لم يُنفَّذ — المرحلة 1)")
    }

    private fun refresh() {
        val rt = ReceiverRuntime
        val pairing = rt.pairing
        pairing.rotateIfExpired()

        val name = rt.controllerName
        statusView.text = when {
            !rt.running -> rt.lastError?.let { getString(R.string.status_error, it) } ?: getString(R.string.status_stopped)
            name != null -> {
                val rtt = if (rt.lastRttMs >= 0) "  •  " + getString(R.string.rtt_fmt, rt.lastRttMs) else ""
                getString(R.string.status_connected, name) + rtt
            }
            else -> getString(R.string.status_waiting)
        }

        val ips = localIPv4()
        addressView.text = if (ips.isEmpty()) getString(R.string.no_network) else ips.joinToString("  |  ")

        val code = pairing.currentCode()
        codeView.text = code.substring(0, 3) + " " + code.substring(3)
        expiryView.text = getString(R.string.code_expires, pairing.codeRemainingMs() / 1000)

        val paired = pairing.pairedDeviceName()
        pairedView.text = if (paired != null) getString(R.string.paired_with, paired) else getString(R.string.not_paired)
        toggleButton.setText(if (rt.running) R.string.btn_stop else R.string.btn_start)
    }

    private fun addLog(line: String) {
        logLines.add(0, "${timeFormat.format(Date())}  $line")
        while (logLines.size > 14) logLines.removeAt(logLines.size - 1)
        logView.text = logLines.joinToString("\n")
    }

    private fun localIPv4(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) {
        emptyList()
    }
}
