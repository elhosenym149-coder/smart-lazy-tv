package com.smartlazytv.tv

import android.content.Context
import com.smartlazytv.core.PairingStore

/** Stores only the SHA-256 hash of the session token plus the paired device's display name. App-private prefs. */
class PrefsPairingStore(context: Context) : PairingStore {
    private val prefs = context.getSharedPreferences("pairing", Context.MODE_PRIVATE)

    override fun loadTokenHash(): String? = prefs.getString("token_hash", null)
    override fun loadPairedDeviceName(): String? = prefs.getString("device_name", null)

    override fun save(tokenHash: String, deviceName: String) {
        prefs.edit().putString("token_hash", tokenHash).putString("device_name", deviceName).apply()
    }

    override fun clear() {
        prefs.edit().clear().apply()
    }
}
