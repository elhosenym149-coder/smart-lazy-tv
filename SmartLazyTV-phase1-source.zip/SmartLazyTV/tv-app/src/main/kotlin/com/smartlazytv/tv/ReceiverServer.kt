package com.smartlazytv.tv

import android.os.SystemClock
import com.smartlazytv.core.AckStatus
import com.smartlazytv.core.Message
import com.smartlazytv.core.MessageType
import com.smartlazytv.core.PairResult
import com.smartlazytv.core.PairingManager
import com.smartlazytv.core.Protocol
import com.smartlazytv.core.TvCommand
import com.smartlazytv.core.TvEvent
import com.smartlazytv.core.normalizeDigits
import com.smartlazytv.core.tvEventFromPayload
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Local WebSocket endpoint of the TV (spec section 6).
 * - A connection must authenticate within AUTH_TIMEOUT_MS (PAIR_REQUEST with the on-screen code, or AUTH with the saved token).
 * - Only one authenticated controller at a time; a new one replaces the old one.
 * - Authenticated connections must send something (PING every 2 s) or are dropped after HEARTBEAT_TIMEOUT_MS.
 * - Phase 1: commands are received, de-duplicated, acknowledged (RECEIVED) and reported. Nothing is executed on the TV yet.
 */
class ReceiverServer(
    port: Int,
    private val pairing: PairingManager,
    private val callbacks: Callbacks
) : WebSocketServer(InetSocketAddress(port)) {

    interface Callbacks {
        fun onServerStarted()
        fun onServerError(e: Exception)
        fun onControllerConnected(name: String)
        fun onControllerDisconnected(reason: String)
        fun onHeartbeat(rttMs: Long)
        fun onCommand(event: TvEvent)
        fun onLog(line: String)
    }

    private class Session(val openedAt: Long) {
        @Volatile var authenticated = false
        @Volatile var deviceName = ""
        @Volatile var sessionId = ""
        @Volatile var lastSeen = openedAt
    }

    private val sessions = ConcurrentHashMap<WebSocket, Session>()
    @Volatile private var activeConn: WebSocket? = null
    @Volatile private var stopping = false
    private var scheduler: ScheduledExecutorService? = null

    // Event-id de-duplication (last 256 ids): one gesture must never execute twice.
    private val recentIds = object : LinkedHashMap<String, Boolean>(256, 0.75f, false) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean = size > 256
    }

    override fun onStart() {
        val s = Executors.newSingleThreadScheduledExecutor()
        scheduler = s
        s.scheduleWithFixedDelay(Runnable { checkSessions() }, 1000, 1000, TimeUnit.MILLISECONDS)
        callbacks.onServerStarted()
    }

    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
        sessions[conn] = Session(SystemClock.elapsedRealtime())
        callbacks.onLog("اتصال وارد من ${conn.remoteSocketAddress?.address?.hostAddress ?: "?"}")
    }

    override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
        val s = sessions.remove(conn)
        if (conn === activeConn) {
            activeConn = null
            callbacks.onControllerDisconnected(if (reason.isNullOrBlank()) "code $code" else reason)
        } else if (s != null && !s.authenticated) {
            callbacks.onLog("أُغلق اتصال غير مصادَق")
        }
    }

    override fun onError(conn: WebSocket?, ex: Exception?) {
        if (stopping) return
        if (conn == null) callbacks.onServerError(ex ?: RuntimeException("unknown server error"))
        else callbacks.onLog("خطأ اتصال: ${ex?.message}")
    }

    override fun onMessage(conn: WebSocket, message: String) {
        val s = sessions[conn] ?: return
        val msg = Message.decode(message)
        if (msg == null) {
            callbacks.onLog("رسالة غير صالحة أُهملت")
            return
        }
        s.lastSeen = SystemClock.elapsedRealtime()

        if (!s.authenticated) {
            when (msg.type) {
                MessageType.PAIR_REQUEST -> handlePair(conn, s, msg.payload)
                MessageType.AUTH -> handleAuth(conn, s, msg.payload)
                else -> callbacks.onLog("رسالة ${msg.type} قبل المصادقة أُهملت")
            }
            return
        }

        when (msg.type) {
            MessageType.PING -> {
                reply(conn, MessageType.PONG, JSONObject().put("t", msg.payload.optLong("t", 0)))
                callbacks.onHeartbeat(msg.payload.optLong("rtt", -1))
            }
            MessageType.EVENT -> handleEvent(conn, s, msg.payload)
            MessageType.UNPAIR -> {
                pairing.unpair()
                callbacks.onLog("الهاتف طلب إلغاء الاقتران")
                conn.close(1000, "unpaired")
            }
            else -> callbacks.onLog("رسالة غير متوقعة: ${msg.type}")
        }
    }

    private fun handlePair(conn: WebSocket, s: Session, p: JSONObject) {
        val code = normalizeDigits(p.optString("code", ""))
        val name = p.optString("name", "Android").take(40)
        when (val r = pairing.tryPair(code, name)) {
            is PairResult.Success -> {
                authenticate(conn, s, name)
                reply(conn, MessageType.PAIR_OK, JSONObject().put("token", r.token).put("sid", s.sessionId))
            }
            PairResult.WrongCode -> reply(conn, MessageType.PAIR_FAIL, JSONObject().put("reason", "wrong_code"))
            PairResult.Expired -> reply(conn, MessageType.PAIR_FAIL, JSONObject().put("reason", "expired"))
            PairResult.LockedOut -> {
                reply(conn, MessageType.PAIR_FAIL, JSONObject().put("reason", "locked"))
                callbacks.onLog("الاقتران مقفل مؤقتًا بسبب محاولات خاطئة")
                conn.close(1008, "locked")
            }
        }
    }

    private fun handleAuth(conn: WebSocket, s: Session, p: JSONObject) {
        val token = p.optString("token", "")
        val name = p.optString("name", "Android").take(40)
        if (token.isNotEmpty() && pairing.verifyToken(token)) {
            authenticate(conn, s, name)
            reply(conn, MessageType.AUTH_OK, JSONObject().put("sid", s.sessionId))
        } else {
            reply(conn, MessageType.AUTH_FAIL, JSONObject().put("reason", "bad_token"))
            callbacks.onLog("مصادقة مرفوضة")
            conn.close(1008, "bad token")
        }
    }

    private fun authenticate(conn: WebSocket, s: Session, name: String) {
        val old = activeConn
        activeConn = conn // set first so the old connection's onClose is not reported as a disconnect
        if (old != null && old !== conn) {
            try { old.close(1000, "replaced") } catch (e: Exception) { /* already closing */ }
        }
        s.authenticated = true
        s.deviceName = name
        s.sessionId = UUID.randomUUID().toString()
        s.lastSeen = SystemClock.elapsedRealtime()
        callbacks.onControllerConnected(name)
    }

    private fun handleEvent(conn: WebSocket, s: Session, p: JSONObject) {
        val ev = tvEventFromPayload(p)
        if (ev == null) {
            reply(conn, MessageType.ACK, ack("", AckStatus.REJECTED))
            callbacks.onLog("حدث غير صالح أُهمل")
            return
        }
        if (ev.sessionId != s.sessionId) {
            reply(conn, MessageType.ACK, ack(ev.eventId, AckStatus.REJECTED))
            callbacks.onLog("حدث بجلسة غير مطابقة رُفض")
            return
        }
        val duplicate = synchronized(recentIds) { recentIds.put(ev.eventId, true) != null }
        if (duplicate) {
            reply(conn, MessageType.ACK, ack(ev.eventId, AckStatus.DUPLICATE))
            return
        }
        // POINTER_MOVE streams at 30-60 Hz: acknowledging each one would double the traffic for no benefit.
        if (ev.command != TvCommand.POINTER_MOVE) {
            reply(conn, MessageType.ACK, ack(ev.eventId, AckStatus.RECEIVED))
        }
        callbacks.onCommand(ev)
    }

    private fun ack(id: String, status: AckStatus) = JSONObject().put("id", id).put("status", status.name)

    private fun reply(conn: WebSocket, type: MessageType, payload: JSONObject = JSONObject()) {
        try {
            conn.send(Message(type, payload).encode())
        } catch (e: Exception) {
            // connection already closed; onClose handles the bookkeeping
        }
    }

    private fun checkSessions() {
        try {
            val now = SystemClock.elapsedRealtime()
            for ((conn, s) in sessions) {
                val expired = if (s.authenticated) now - s.lastSeen > Protocol.HEARTBEAT_TIMEOUT_MS
                else now - s.openedAt > Protocol.AUTH_TIMEOUT_MS
                if (expired) {
                    try { conn.close(1008, if (s.authenticated) "heartbeat timeout" else "auth timeout") } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) {
            callbacks.onLog("خطأ في مراقبة الجلسات: ${e.message}") // never let the scheduled task die silently
        }
    }

    /** Closes the authenticated controller (used when the TV user unpairs). */
    fun disconnectController() {
        val c = activeConn ?: return
        try { c.close(1000, "unpaired") } catch (e: Exception) { }
    }

    fun shutdownServer() {
        stopping = true
        scheduler?.shutdownNow()
        try { stop(300) } catch (e: Exception) { }
    }
}
