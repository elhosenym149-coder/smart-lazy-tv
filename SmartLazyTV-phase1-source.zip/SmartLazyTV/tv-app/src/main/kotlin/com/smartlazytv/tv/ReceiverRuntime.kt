package com.smartlazytv.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.smartlazytv.core.PairingManager
import com.smartlazytv.core.Protocol
import com.smartlazytv.core.TvEvent

/**
 * Process-wide owner of the server and pairing state, so they survive Activity re-creation.
 * Phase 1 limitation: lives only as long as the app process (no foreground service / AccessibilityService yet).
 */
object ReceiverRuntime : ReceiverServer.Callbacks {

    interface Listener {
        fun onChanged()
        fun onLog(line: String)
        fun onCommand(event: TvEvent)
    }

    private val main = Handler(Looper.getMainLooper())
    private var server: ReceiverServer? = null
    private var pairingOrNull: PairingManager? = null

    @Volatile var listener: Listener? = null

    @Volatile var running: Boolean = false
        private set
    @Volatile var controllerName: String? = null
        private set
    @Volatile var lastRttMs: Long = -1
        private set
    @Volatile var lastError: String? = null
        private set

    val pairing: PairingManager
        get() = pairingOrNull ?: error("ReceiverRuntime.init() was not called")

    @Synchronized
    fun init(context: Context) {
        if (pairingOrNull == null) pairingOrNull = PairingManager(PrefsPairingStore(context.applicationContext))
    }

    @Synchronized
    fun start() {
        if (server != null) return
        val s = ReceiverServer(Protocol.DEFAULT_PORT, pairing, this)
        s.isReuseAddr = true
        s.connectionLostTimeout = 6
        server = s
        lastError = null
        s.start()
    }

    @Synchronized
    fun stop() {
        val s = server ?: return
        server = null
        running = false
        controllerName = null
        lastRttMs = -1
        Thread { s.shutdownServer() }.start()
        notifyChanged()
    }

    @Synchronized
    fun unpair() {
        pairing.unpair()
        server?.disconnectController()
        notifyChanged()
    }

    private fun notifyChanged() { main.post { listener?.onChanged() } }
    private fun log(line: String) { main.post { listener?.onLog(line) } }

    override fun onServerStarted() {
        running = true
        log("الخدمة تعمل على المنفذ ${Protocol.DEFAULT_PORT}")
        notifyChanged()
    }

    override fun onServerError(e: Exception) {
        synchronized(this) {
            running = false
            server = null
            lastError = e.message ?: e.javaClass.simpleName
        }
        log("فشل تشغيل الخدمة: ${e.message}")
        notifyChanged()
    }

    override fun onControllerConnected(name: String) {
        controllerName = name
        lastRttMs = -1
        log("اتصل الهاتف: $name")
        notifyChanged()
    }

    override fun onControllerDisconnected(reason: String) {
        controllerName = null
        lastRttMs = -1
        log("انقطع الهاتف ($reason)")
        notifyChanged()
    }

    override fun onHeartbeat(rttMs: Long) {
        lastRttMs = rttMs
        notifyChanged()
    }

    override fun onCommand(event: TvEvent) {
        main.post {
            listener?.onCommand(event)
        }
    }

    override fun onLog(line: String) = log(line)
}
