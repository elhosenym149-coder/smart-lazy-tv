# دليل التثبيت (المرحلة 1) — Windows 10

> لا توجد ملفات APK جاهزة. تُبنى على جهازك بالخطوات التالية. لم أتمكن من تجربة هذه الخطوات.

## 1) فتح المشروع وبنائه
1. ثبّت Android Studio (ومعه JDK 17 أو أحدث) وافتح مجلد `SmartLazyTV`.
2. انتظر مزامنة Gradle (تحتاج إنترنت أول مرة). سيُنزّل Gradle 8.7 من `gradle-wrapper.properties`، وسيطلب تثبيت **Android SDK Platform 34**؛ وافق.
3. إن اقترح Android Studio ترقية Android Gradle Plugin فوافق، وأرسل لي نص أي خطأ.
4. شغّل اختبارات الوحدة: كليك يمين على `shared-core/src/test` ← Run Tests.
5. ابنِ التطبيقين: من قائمة الوحدات اختر `mobile-app` ثم Build ← Build APK(s)، وكرّر مع `tv-app`.
6. الملفان الناتجان:
   - `mobile-app\build\outputs\apk\debug\mobile-app-debug.apk`
   - `tv-app\build\outputs\apk\debug\tv-app-debug.apk`
7. (اختياري) نسخهما لمسارات واضحة، في PowerShell داخل مجلد المشروع:
```
New-Item -ItemType Directory -Force output\mobile, output\tv
Copy-Item mobile-app\build\outputs\apk\debug\mobile-app-debug.apk output\mobile\SmartLazyTV-Mobile.apk
Copy-Item tv-app\build\outputs\apk\debug\tv-app-debug.apk output\tv\SmartLazyTV-TV.apk
```
ملاحظة: `gradlew` غير موجود في المشروع. إن أردت سطر الأوامر ثبّت Gradle ونفّذ `gradle wrapper --gradle-version 8.7` مرة واحدة.

## 2) تثبيت تطبيق الموبايل
- **بدون ADB:** انقل `SmartLazyTV-Mobile.apk` للهاتف، افتحه، واسمح بالتثبيت من هذا المصدر.
- **بـ ADB:** فعّل USB debugging في الهاتف، وصّله، ثم `adb install -r SmartLazyTV-Mobile.apk`.

## 3) تثبيت تطبيق التلفزيون (Toshiba)
1. على التلفزيون: الإعدادات ← تفضيلات الجهاز ← حول ← اضغط **Build** سبع مرات. (أسماء القوائم قد تختلف في HiSmart.)
2. خيارات المطور ← فعّل USB debugging، وإن وُجد **Network debugging / ADB over network** فعّله.
3. على Windows، افتح PowerShell:
```
cd $env:LOCALAPPDATA\Android\Sdk\platform-tools
.\adb.exe connect <عنوان-IP-التلفزيون>:5555
.\adb.exe install -r <المسار>\SmartLazyTV-TV.apk
```
4. اقبل نافذة "Allow USB debugging" على التلفزيون.
5. **بديل بدون ADB:** وحدة USB أو تطبيق نقل ملفات للتلفزيون، ثم افتح الـ APK من مدير ملفات على التلفزيون (قد تحتاج السماح بالمصادر غير المعروفة).

## 4) الربط
1. افتح **Smart Lazy TV** على التلفزيون: يظهر عنوان IP ورمز من 6 أرقام.
2. على الهاتف (على نفس شبكة Wi-Fi): أدخل العنوان والرمز واضغط **اقتران واتصال**.
3. عند النجاح تظهر "متصل" على الجهازين.

## 5) الاختبار
اضغط أزرار الأوامر في الهاتف: يجب أن يظهر اسم الأمر على التلفزيون ويصل ACK للهاتف. (الأوامر لا تُنفَّذ على التلفزيون في هذه المرحلة.) سجّل نتائجك في `Testing.md`.

## 6) إعادة الاتصال
- انقطاع Wi-Fi: الهاتف يعيد المحاولة تلقائيًا.
- أُغلق تطبيق الهاتف: افتحه، أو اضغط **اتصال (مقترن سابقًا)**.
- فشل الاتصال بعد إلغاء الاقتران: اقترن من جديد بالرمز.

## لاحقًا (غير متاح الآن)
معايرة المؤشر (المرحلة 2)، معايرة الحركات وAir Tap والتنقل (المرحلة 3)، الصلاحيات على التلفزيون (المرحلة 4).
