# Architecture (Phase 1)

## الوحدات
- **shared-core**: `Protocol.kt` (ثوابت، `MessageType`، `TvCommand`، `Message`، `TvEvent`، `normalizeDigits`) و`PairingManager.kt`.
- **tv-app**: `ReceiverServer` (WebSocket server) ← `ReceiverRuntime` (مالك الخادم على مستوى العملية) ← `MainActivity`.
- **mobile-app**: `TvClient` (اتصال + اقتران + نبض + إعادة اتصال) + `KeystoreBox`/`SecureClientStore` + `MainActivity`.

الوحدات المقترحة في الوثيقة (motion-engine, gesture-engine, calibration-engine, action-gateway, accessibility-module, spatial-core, voice-module, claude-provider) **لم تُنشأ بعد**؛ تُضاف في مرحلتها حتى لا توجد وحدات فارغة.

## البروتوكول
الغلاف: `{"v":1,"t":"TYPE","p":{...}}` على `ws://<TV_IP>:8765`. أقصى حجم رسالة 4096 حرفًا.

```
أول اقتران:  Phone -> PAIR_REQUEST{code,name}  -> TV: PAIR_OK{token,sid} | PAIR_FAIL{reason}
لاحقًا:       Phone -> AUTH{token,name}         -> TV: AUTH_OK{sid}       | AUTH_FAIL
بعد المصادقة: Phone -> PING{t,rtt} كل 2 ث      -> TV: PONG{t}
أوامر:        Phone -> EVENT{id,cmd,src,ts,conf,target,params,sid} -> TV: ACK{id,status}
```
- `ACK.status = RECEIVED` تعني الاستلام فقط، **لا** التنفيذ. (EXECUTED/FAILED تُضاف مع Action Gateway في المرحلة 4.)
- `POINTER_MOVE` لا يُرسل له ACK (بث 30–60 Hz).
- يرفض التلفزيون: رسالة قبل المصادقة، جلسة غير مطابقة، حدثًا مكررًا (آخر 256 معرّف).

## الأمان (ما هو مطبّق فعلًا في الكود)
- رمز اقتران من 6 أرقام، صلاحيته 120 ث، يُستهلك عند النجاح، 5 محاولات خاطئة = قفل 60 ث.
- رمز الجلسة 256 بت عشوائي. التلفزيون يخزّن **بصمة SHA-256 فقط**. الهاتف يخزّنه مشفّرًا بمفتاح Android Keystore (AES-GCM).
- مهلة مصادقة 5 ث، مهلة نبض 6 ث، متحكم واحد فقط في الوقت نفسه.
- **غير مطبّق:** تشفير النقل (الاتصال `ws://` غير مشفّر على الشبكة المحلية). انظر Known-Limitations.md.

## الإصدارات المختارة (لم تُجرَّب لأن البناء لم يتم)
AGP 8.5.2 · Gradle 8.7 · Kotlin 1.9.24 · JDK 17 · compile/targetSdk 34 · minSdk 26 · Java-WebSocket 1.5.7 (عميل وخادم من مكتبة واحدة).
